/**
 * 
 */
package pHW04_GUI_T142974;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

/**
 * @author Luong Quoc Thai T142974
 *
 */
public class cHW04_Prog02_SquareRoot_T142974 extends JFrame {
	JLabel l1 = new JLabel("Nhập Số : "), l2 = new JLabel("Chọn Sai Số : ");
	JTextField txt1 = new JTextField();
	JButton b1 = new JButton("Tính"), b2 = new JButton("Xóa"),
			b3 = new JButton("Xóa Hết");
	JTextArea a = new JTextArea();
	JScrollPane b = new JScrollPane(a);
	String[] cbb = { "1", "2", "3", "4", "5", "6", "7", "8" };
	JComboBox c = new JComboBox(cbb);

	int Wn;
	double num;

	public static void main(String[] args) {
		cHW04_Prog02_SquareRoot_T142974 wMain = new cHW04_Prog02_SquareRoot_T142974();
		wMain.setDefaultCloseOperation(EXIT_ON_CLOSE);
		wMain.setVisible(true);

	}

	public cHW04_Prog02_SquareRoot_T142974() {
		setTitle("T142974 - Square Root ");
		setSize(300, 350);
		setLayout(null);
		add(l1);
		add(l2);
		add(txt1);
		add(b1);
		add(b2);
		add(b3);
		add(b);
		add(c);
		l1.setBounds(10, 10, 70, 25);
		txt1.setBounds(85, 10, 150, 25);
		l2.setBounds(50, 40, 100, 25);
		b1.setBounds(20, 80, 80, 25);
		b2.setBounds(105, 80, 80, 25);
		b3.setBounds(190, 80, 80, 25);
		b.setBounds(10, 110, 260, 150);
		c.setBounds(140, 40, 100, 25);
		c.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				JComboBox cb = (JComboBox) c;
				String so = (String) cb.getSelectedItem();
				Wn = Integer.parseInt(so);
				
			}
		});
		b1.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					num = Double.parseDouble(txt1.getText());
					if(num<0){
						a.append(" Invalid Input "+"\n");

					}
				} catch (NumberFormatException exception) {
					a.append(" Invalid Input "+"\n");
				}

			}
		});
	}
}

/**
 * 
 */
package pHW04_GUI_T142974;

/**
 * @author Luong Quoc Thai T142974
 *
 */
public class cHW04_Prog07_Oct2Bin_T142974 {

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}

/**
 * 
 */
package pHW01_GUI_Swing_T142974;

/**
 * @luong quoc thai T142974
 *
 */
public class cHW01_Prog06B_T142974 {
 
	 public static void printToConsole(int n) {
		for(int i=1;i<=n;i=+i+2){
			System.out.print(i+" ");
		}
		
	 }
		 
		 
	 
 }


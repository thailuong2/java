import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.Timer;

/**
 * 
 */

/**
 * Luong Quoc Thai T142974
 *
 */
public class cHW03_Prog02_ManualTrafficControl_v2_T142974 extends JFrame {
	cHW03_Prog02_ManualTrafficControl_v2_Panel_T142974 a = new cHW03_Prog02_ManualTrafficControl_v2_Panel_T142974();
	JLabel Gt = new JLabel("Red Time"), Rt = new JLabel("Green Time"),
			Yt = new JLabel("Yellow Time");
	JTextField sG = new JTextField(), sR = new JTextField(),
			sY = new JTextField();
	
	JButton apply = new JButton("Apply");
	int gt, rt, yt, c = 0, x = 0, g = 1000;

	public static void main(String[] args) {
		cHW03_Prog02_ManualTrafficControl_v2_T142974 wMain = new cHW03_Prog02_ManualTrafficControl_v2_T142974();
		wMain.setDefaultCloseOperation(EXIT_ON_CLOSE);
		wMain.setVisible(true);

	}

	public cHW03_Prog02_ManualTrafficControl_v2_T142974() {
		setTitle("Traffic Light Control");
		setSize(500, 500);
		setLayout(null);
		add(sR);
		add(sG);
		add(sY);
		add(Gt);
		add(Rt);
		add(Yt);
		Gt.setBounds(10, 10, 80, 20);
		sG.setBounds(100, 10, 50, 20);
		Rt.setBounds(10, 35, 80, 20);
		sR.setBounds(100, 35, 50, 20);
		Yt.setBounds(10, 60, 80, 20);
		sY.setBounds(100, 60, 50, 20);
		add(apply);
		apply.setBounds(50, 100, 80, 25);
		
		add(a);
		a.setBounds(10, 150, 300, 300);
		apply.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {

				try {
					// chuyển chuổi nhập vào thành số
					gt = Integer.parseInt(sG.getText());
					rt = Integer.parseInt(sR.getText());
					yt = Integer.parseInt(sY.getText());
					Timer s = new Timer(g, new ActionListener() {

						public void actionPerformed(ActionEvent arg0) {

							x = x + g;
							// điều kiện để chạy
							if (c == 0) {

								if (x <= gt * 1000) {
									// gọi hàm vẽ đèn đỏ
									a.redT();
								} 
								//điều kiện để chuyển đèn
								//tương tự với 2 đèn còn lại
								else {
									c = 1;
									x = 0;
								}
							}
							if (c == 1) {
								if (x <= rt * 1000) {
									a.greenT();
								} else {
									c = 2;
									x = 0;
								}
							}
							if (c == 2) {
								if (x <= yt * 1000) {
									a.yellowT();
								} else {
									c = 0;
									x = 0;
								}
							}
						}
					});
					s.start();
				} catch (NumberFormatException e2) {
					System.out.print("loi");
				}

			}
		});
	}
}
//end class

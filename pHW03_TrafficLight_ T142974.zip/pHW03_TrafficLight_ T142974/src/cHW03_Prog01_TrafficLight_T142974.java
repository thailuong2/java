import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.Timer;

/**
 * 
 */

/**
 * Luong Quoc Thai T142974
 *
 */
public class cHW03_Prog01_TrafficLight_T142974 extends JFrame {
	cHW03_Prog01_TrafficLight_Panel_T142974 a = new cHW03_Prog01_TrafficLight_Panel_T142974();
	cHW03_Prog02_CarAnimation_Panel_T142974 b = new cHW03_Prog02_CarAnimation_Panel_T142974();
	private int i = 0, x = 1000;
	private int t = 0, c = 0;
	private int timeR = 1, timeG = 1, timeY = 1;

	public static void main(String[] args) {
		cHW03_Prog01_TrafficLight_T142974 wMain = new cHW03_Prog01_TrafficLight_T142974();

		wMain.setDefaultCloseOperation(EXIT_ON_CLOSE);
		wMain.setVisible(true);
	}

	public cHW03_Prog01_TrafficLight_T142974() {
		setSize(1000, 1000);
		setLayout(null);
		
		add(a);
		a.setBounds(0, 0, 1000, 1000);
		
		Timer L = null;
		L = new Timer(x, new ActionListener() {

			public void actionPerformed(ActionEvent e) {

				i = i + x;
				if (c == 0) {
					if (i <= timeR * x) {
						a.red();
					} else {
						i = 0;
						c = 1;
					}
				}
				if (c == 1) {
					if (i <= timeG * 1000) {
						a.green();
					} else {
						i = 0;
						c = 2;
					}
				}
				if (c == 2) {
					if (i <= timeY * 1000) {
						a.yellow();
					} else {
						i = 0;
						c = 0;
					}
				}
			}
		});
		L.start();
		add(b);
		b.setBounds(0,350,1000,100);
	}
}

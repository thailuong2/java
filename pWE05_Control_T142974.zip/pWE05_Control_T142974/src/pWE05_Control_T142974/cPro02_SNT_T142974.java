/**
 * 
 */
package pWE05_Control_T142974;

import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

/**
 * Luong quoc thai T142974
 *
 */
public class cPro02_SNT_T142974 extends JFrame {
	JTextField txt1 = new JTextField();
	JLabel lbl1 = new JLabel("Input");
	JTextArea a1 = new JTextArea();
	JButton bnt1 = new JButton("CLEAR"), bnt2 = new JButton("CLEAR ALL"),
			bnt3 = new JButton("Check");
	int x, n1, n2, y;

	public static void main(String[] args) {
		cPro02_SNT_T142974 wMain = new cPro02_SNT_T142974();
		wMain.setDefaultCloseOperation(EXIT_ON_CLOSE);
		wMain.setVisible(true);
	}

	public cPro02_SNT_T142974() {
		setTitle("SNT-T142974");
		setSize(300, 300);
		setLayout(null);
		Insets insButton = new Insets(1, 1, 1, 1);
		add(txt1);
		add(a1);
		add(lbl1);
		lbl1.setBounds(10, 10, 50, 20);
		txt1.setBounds(70, 10, 100, 25);
		a1.setBounds(10, 40, 200, 80);
		bnt1.setMargin(insButton);
		add(bnt1);
		add(bnt2);
		add(bnt3);
		bnt1.setBounds(10, 150, 65, 25);
		bnt2.setMargin(insButton);
		bnt2.setBounds(80, 150, 80, 25);
		bnt3.setMargin(insButton);
		bnt3.setBounds(165, 150, 85, 25);
		bnt1.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				txt1.setText("");
			}
		});
		bnt2.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				txt1.setText("");
				a1.setText("");
			}
		});
		bnt3.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				String n = txt1.getText();
				try {
					x = Integer.parseInt(n);
					if (x <= 0) {
						a1.append("Invalid Input" + "\n");

					}
				} catch (NumberFormatException exception) {
					a1.append("Invalid Input" + "\n");
				}
			}
		});
	}
}
